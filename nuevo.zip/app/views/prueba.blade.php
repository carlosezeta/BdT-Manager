@extends('site.layout')

@section('content')
{{ var_dump($categorias) }}

@stop