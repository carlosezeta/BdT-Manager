@extends('site.layout')

@section('content')

<h1>Intercambio pagado.</h1>

@stop