<?php

return array(
	'todos' 		=> 'Todos los intercambios',
	'pagar' 		=> 'Pagar un intercambio',
	'fecha' 		=> 'Fecha',
	'de'			=> 'De',
	'a'				=> 'A',
	'horas'			=> 'Horas',
	'descripcion'	=> 'Descripción'

);