<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Textos de las vistas de "Talleres"
	|--------------------------------------------------------------------------
	*/
	'publicar' => 'Publicar Taller',
	'proponer' => 'Proponer Taller'
);