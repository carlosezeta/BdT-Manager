<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Textos comunes a varias vistas
	|--------------------------------------------------------------------------
	*/

	'idioma'		=> 'es',//Código del idioma con dos letras: 'es', 'ca', 'en', 'gl'.
	'delete'		=> 'Eliminar',
	'edit'			=> 'Editar',
	'actualizar'	=> 'Actualizar',
	'cancelar'		=> 'Cancelar',
	'inicio'		=> 'Inicio',
	'ofertas'		=> 'Ofertas',
	'demandas'		=> 'Demandas',
	'intercambios'	=> 'Intercambios',
	'talleres'		=> 'Talleres',
	'no-hay-nada'	=> 'No hay resultados que mostrar.',
	'subir'			=> 'Subir'
);
