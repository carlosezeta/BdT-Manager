<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Textos de las vistas de "Categorías"
	|--------------------------------------------------------------------------
	*/

	'todas' => 'Todas las categorías',
	'nueva'	=> 'Nueva Categoría',
	'nombre' => 'Nombre',
	'descripcion' => 'Descripción',
	'ninguna' => 'No hay categorías',
	'ver' => 'Ver Categoría',
	'volver' => 'Volver a Todas las categorías',
);
