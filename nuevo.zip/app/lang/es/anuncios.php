<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Textos de las vistas de "Anuncios"
	|--------------------------------------------------------------------------
	*/

	'categoria_required'	=> 'Debe seleccionar una categoría',
	'titulo_required'		=> 'Debe escribir un título',
	'descripcion_required'	=> 'Debe rellenar la descripción',
	'oferta_min'			=> 'oferta',
	'demanda_min'			=> 'demanda',
	'publicar_anuncio'		=> 'Publicar anuncio',
	'editar_anuncio'		=> 'Editar Anuncio',
	'publicar'				=> 'Publicar',
	'publicar_oferta'		=> 'Publicar Oferta',
	'publicar_demanda'		=> 'Publicar Demanda',
	'titulo'				=> 'Título',
	'categoria'				=> 'Categoría',
	'selecciona_categoria'	=> 'Selecciona una categoría',
	'descripcion'			=> 'Descripción',
	'tipo'					=> 'Tipo',
	'oferta'				=> 'Oferta',
	'demanda'				=> 'Demanda'
	
);
