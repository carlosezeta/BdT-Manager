<?php

class TallersTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('tallers')->truncate();

		$tallers = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('tallers')->insert($tallers);
	}

}
