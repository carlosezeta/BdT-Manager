<?php

class PropuestasTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('propuestas')->truncate();

		$propuestas = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('propuestas')->insert($propuestas);
	}

}
